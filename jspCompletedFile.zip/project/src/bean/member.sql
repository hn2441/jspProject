create table member(
id varchar(20) primary key,
pw varchar(64),
name varchar(20),
tel varchar(20),
category boolean,
salt varchar(32)
);

insert into member values('admin@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('asd@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('asd@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('asp@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('ase@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('as1@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('asw@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('ase@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('asr@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('as3@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('as6@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('as2@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('as9@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');
insert into member values('as@naver.com','ad23e3b84146aa599ec4731471e279eb790b696bdb97f17cd4a23bb792a7ed0e','root','010-2020-3030',true,'e7f6c011776e8db7cd330b54174fd76f');