create table count(
visitDate Date,
count int
);

insert into count values('2019-1-10','5');
insert into count values('2019-1-11','3');
insert into count values('2019-1-12','4');
insert into count values('2019-1-13','3');