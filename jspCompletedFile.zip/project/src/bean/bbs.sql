create table bbs(
num serial, 
title varchar(50),
write varchar (500), 
id varchar(20),
id2 varchar(20), 
date varchar(20), 
view integer);

	insert into bbs values('1','title','write','id','id2','date','1');